import React from 'react';
import {Badge} from 'react-bootstrap'

const styleTitle = {
    display: 'flex',
    borderColor: 'black',
    alignitems: 'center',
    justifycontent: 'center',
    width: '100%',
    allign: 'center',
    justifyContent:'left',
    color: 'black',
    borderRadius:'9999',
}
interface ITitleProps{
    name: string
}

class Title extends React.Component<ITitleProps>{
    public render(){
       return (
            <h1 className='container col-lg-12' style={styleTitle}><Badge variant="secondary">{this.props.name}</Badge></h1>
       )
    }
}
    
export default Title;