import React from 'react'
import Select from 'react-select'

interface IDropDownProps{
    data: string[],
    name?: string
}
/*
const styleSelect={
    padding: '10px',
    margin: '10px',
    borderRadius: 999,
    color: 'black',
    borderColor: 'black',
    background: 'white',
}*/

/*interface ISiglas{
    value: string,
    label: string
}*/

class DropDownList extends React.Component<IDropDownProps>{
    constructor(props: IDropDownProps) {
        super(props);
        this.cargarData.bind(this)
      }
      cargarData() {
        const aData = [{}]
        const data = this.props.data
        data.map((x)=>(
            aData.push({value:x.toString(),label:x.toString()})
            ))
         return aData
      }
    public render(){
        return (
            <Select placeholder={this.props.name ? this.props.name : 'Select'} options={this.cargarData()}/>
        )
    }
}
    
export default DropDownList
