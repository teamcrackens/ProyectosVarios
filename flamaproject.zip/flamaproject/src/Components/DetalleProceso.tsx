import React from 'react';
import Title from './Title'

import { Form} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const abscentercontainer = {
    display: 'flex',
    alignitems: 'center',
    justifycontent: 'center',
    minheight: '100vh',
    border: '1px solid #333',
    background:'grey'
  }

  interface IDetalleProcesoProps{
      data: {
          nombre: string,
          descripcion: string,
          reejecucion: boolean
      }
  }

class DetalleProceso extends React.Component<IDetalleProcesoProps>{
    public render(){
        const Detalle = this.props.data
        return (
            <div>
                <div className='container' style={abscentercontainer}>
                        <Title name='Detalle Proceso'/>
                    </div>
                    <div className='container dark' style={abscentercontainer}>
                        <div style={{borderColor:'black', width: '100%'}}>
                            <Form>
                                <Form.Group controlId="DetalleProcesoID">
                                        <Form.Label style={{fontStyle:'solid',color: 'white'}}>Proceso:</Form.Label>
                                        <Form.Control value={Detalle.nombre} disabled></Form.Control>
                                        <Form.Label style={{fontStyle:'solid',color: 'white'}}>Descripcion:</Form.Label>
                                        <Form.Control className='col-lg-12' value={Detalle.descripcion} disabled></Form.Control>
                                </Form.Group>
                                <Form.Group controlId="checkReRunId">
                                    <Form.Label style={{fontStyle:'solid',color: 'white'}}>Re-Run:</Form.Label>
                                    <Form.Control className='col-lg-12' value={Detalle.reejecucion ? 'Sin Problemas':'Imposible'} disabled></Form.Control>
                                </Form.Group>     
                            </Form>
                        </div>
                    </div>
            </div>        
        )
    }
}

export default DetalleProceso