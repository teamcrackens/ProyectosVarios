import React from 'react';
import './App.css';
import { Nav, Navbar,NavDropdown } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  Link
} from "react-router-dom";


function App() {
  return (
    <div className="App">
            <Navbar bg="light" expand="lg">
                    <Navbar.Brand href="#">Proyecto Guardias</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="mr-auto">
                        <Nav.Link>
                            <Link to="/">Inicio</Link>
                        </Nav.Link>
                        <NavDropdown title="Acciones" id="basic-nav-dropdown">
                        <NavDropdown.Item>
                            <Link to="/Consulta">Consulta Sigla</Link>
                        </NavDropdown.Item>
                        <NavDropdown.Divider />
                        <NavDropdown.Item>
                            <Link to="/AltaProceso">Alta Proceso</Link>
                        </NavDropdown.Item>
                        <NavDropdown.Item>
                            <Link to="/AltaResolucion">Alta Resolucion</Link>
                        </NavDropdown.Item>
                        </NavDropdown>
                    </Nav>
                    </Navbar.Collapse>
                </Navbar>     
    </div>
  );
}

export default App;