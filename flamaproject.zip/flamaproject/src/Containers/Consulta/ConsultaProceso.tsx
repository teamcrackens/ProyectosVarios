//import * as react from 'react'
import React from 'react';
import Title from '../../Components/Title'
import FormBusqueda from '../../Components/FormBusqueda'
import GrillaIncidencias from '../../Components/GrillaIncidencias'
import DetalleProceso from '../../Components/DetalleProceso'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Col,Row,Image} from 'react-bootstrap'
import guardian from './guardian.jpg'

class ConsultaProceso extends React.Component{
    public render(){
        const Detalle=[{nombre:'HQRM_DGPC',descripcion:'Alta de Paquetes y Componentes STARD.',reejecucion: true}]
        return (
            <div className='container-fluid'>
                <Row>
                    <Col xs={0} md={3}>
                        <Image src={guardian}/>  
                    </Col>
                    <Col xs={12} md={6}>
                        <Title name='Consulta Procesos'/>          
                        <FormBusqueda />
                        <DetalleProceso data={Detalle[0]}></DetalleProceso>
                        <GrillaIncidencias data={[{proceso:'asd',error:'asd',resolucion:'asd'}]} proceso='HQRM_DGPC'/>    
                    </Col>
                    <Col xs={0} md={3}>
                        <Image src={guardian}/>
                    </Col>
                </Row>      
            </div>            
        )
    }
}
    
export default ConsultaProceso;